<?php
echo"ingrese su numero";
$Edad = $_POST['txtEdad'];
$Nombre = $_POST['txtnombre'];
$Genero = $_POST['txtgenero'];
echo"Nombre es: ". $Nombre;
echo"Edad es: ". $Edad;
echo"Genero es es: ". $Genero;

?>