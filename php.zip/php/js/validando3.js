var pf={
    entradas: document.querySelectorAll("input.form-control"),
    valor: null


}
var mf = {
    inicioformulario:function(){
        for(var i=0 ; i < pf.entradas.length; i++){
         pf.entradas[i].addEventListener("focus",mf.enfocar);
         pf.entradas[i].addEventListener("blur",mf.fuerafoco);
         }
    },
    enfocar:function(input)
    {
    pf.valor = input.target.value;
    if(pf.valor==""){
        document.querySelector("#"+input.target.id).style.background ="orange";
    } 

    },
    fuerafoco:function(input){
        pf.valor=input.target.value;
        if(pf.valor ==""){
document.querySelector("#"+input.target.id).style.background="white";
        }
    },
    validarcampos:function(){
      const Nombre = Number(document.querySelector('#txtn1').value)
      
    const Cantidad=Number (document.querySelector('#txtn2').value)
    const Totalven=Number (document.querySelector('#txtn3').value)
    const Nota4=Number (document.querySelector('#txtn4').value)
    const Nota5=Number (document.querySelector('#txtn5').value)
     if(Nombre === ''|| Cantidad=== '' || Totalven === '' || Nota4 ==='' || Nota5 ==='')
    {
     
       alert("Todos los campos son obligatorioa");

    }else if(Cantidad <= 0 || Totalven <=0 || Nombre <= 0|| Nota4 <=0|| Nota5<= 0|| isNaN(Cantidad) || isNaN(Totalven) || isNaN(Nombre)|| isNaN(Nota4)|| isNaN(Nota5)){
        alert("Los datos no son correctos");

    }
}
}; 
mf.inicioformulario();
 