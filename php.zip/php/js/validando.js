var pf={
    entradas: document.querySelectorAll("input.form-control"),
    valor: null


}
var mf = {
    inicioformulario:function(){
        for(var i=0 ; i < pf.entradas.length; i++){
         pf.entradas[i].addEventListener("focus",mf.enfocar);
         pf.entradas[i].addEventListener("blur",mf.fuerafoco);
         }
    },
    enfocar:function(input)
    {
    pf.valor = input.target.value;
    if(pf.valor==""){
        document.querySelector("#"+input.target.id).style.background ="orange";
    } 

    },
    fuerafoco:function(input){
        pf.valor=input.target.value;
        if(pf.valor ==""){
document.querySelector("#"+input.target.id).style.background="white";
        }
    },
    validarcampos:function(){
      const Nombre = document.querySelector('#txt1').value;
      
    const Cantidad=Number (document.querySelector('#txtn1').value)
    const Totalven=Number (document.querySelector('#txtn2').value)
     if(Nombre === ''|| Cantidad=== '' || Totalven === '')
    {
     
       alert("Todos los campos son obligatorioa");

    }else if(Cantidad <= 0 || Totalven <=0 || isNaN(Cantidad) || isNaN(Totalven) ){
        alert("Los datos no son correctos");

    }
}
}; 
mf.inicioformulario();
 