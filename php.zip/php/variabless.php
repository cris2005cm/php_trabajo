<?php

function imc(){
    $Nombre = $_POST ['txt1'];
    $Peso = $_POST ['txtn1'];
    $Estatura = $_POST ['txtn2'];
    $IMC1 = $Estatura*$Estatura;
    $IMC2 = $Peso/$IMC1;
    
    echo("El IMC de: ") .$Nombre; 
    echo("<br>");
    echo(  "Es de: ".$IMC2 );
    echo("<br>");
    if($IMC2<18.5){
         echo("Su IMC esta por debajo del peso");
    }else if ($IMC2>18.5 && $IMC2<24.9){
        echo("Su IMC es Saludable");
    }if ($IMC2>25 &&  $IMC2<29.9){
        echo("Su IMC es con sobrepeso");
    }
    if ($IMC2>30 &&  $IMC2<39.9){
        echo("Su IMC es Obeso");
    }if ($IMC2>40 ){
        echo("Su IMC es Obesidad Mordiba");
    };
 } ;
imc();
 
 ?>
