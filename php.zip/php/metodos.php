<?php

function sumar(){
 $Numero1 = $_POST ['txtn1'];
 $Numero2 = $_POST ['txtn2'];
 $Numero3 = $_POST ['txtn3'];


 $Suma = (($Numero1+$Numero2+$Numero3) /3)*0.35;
 
 echo"<br>";

 echo"El parcial es " .$Suma ;
 $Numero4 = $_POST ['txtn4' ];
 $ExaFinal= $Numero4 * 0.35;
 echo"<br>";
 echo"El Examen Final es " .$ExaFinal ;

 $Numero5 = $_POST ['txtn5'];

 $TrabaFinal =$Numero5 * 0.3;
 echo"<br>";

 echo"El Trabajo Final es " .$TrabaFinal ;

 $NotaFinal = $ExaFinal+$TrabaFinal+$Suma;
 
 echo"<br>";

 echo"Nota final es de  " .$NotaFinal;
 if ($NotaFinal>=3.6 )
 {
    echo"<br>";
    echo"Paso con" .$NotaFinal;

 }else{
    echo"Reprobo con: " .$NotaFinal;

 }
 
};


sumar();


?>