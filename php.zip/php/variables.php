<?php

function salario(){
    $Nombre = $_POST ['txt1'];
    $Cantidad = $_POST ['txtn1'];
    $Precio = $_POST ['txtn2'];
    $Venta= $Cantidad*50000;
    $Comision= $Precio*0.05;
    $Salario= $Venta+$Comision+737000;
    
    echo("El salario de: ") .$Nombre; 
    echo("<br>");
    echo(  "Es de: ".$Salario );
 } ;
salario();

 ?>
